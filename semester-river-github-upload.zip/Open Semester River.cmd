@echo off
start "" "%~dp0semester_river.html"
