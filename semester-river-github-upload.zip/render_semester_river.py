from __future__ import annotations

import math
from datetime import date
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


OUT = Path("semester_river_decomposed.png")
SCALE = 2
W, H = 1100, 1940
TOP_Y, BOTTOM_Y = 100, 1810
WEEKS = 16
WEEK_H = (BOTTOM_Y - TOP_Y) / WEEKS
CURRENT_OFFSETS = [-66, -22, 22, 66]
SEMESTER_START = date(2026, 1, 12)

PALETTES = [
    {"name": "Slate Blue", "primary": "#5D6F8F", "shadow": "#34435E", "highlight": "#A8B4C8"},
    {"name": "Moss Green", "primary": "#66785F", "shadow": "#354533", "highlight": "#A9B59B"},
    {"name": "Terracotta", "primary": "#B96F53", "shadow": "#6F3F32", "highlight": "#D9A18D"},
    {"name": "Deep Sand", "primary": "#A58A62", "shadow": "#5D4B34", "highlight": "#D6C39D"},
]

ASSIGNMENTS = [
    {"assignment_name": "Reading Response", "due_date": "01/23", "weight": "5%", "course_name": "Literature Studio"},
    {"assignment_name": "Field Notes", "due_date": "02/06", "weight": "10%", "course_name": "Ecology Lab"},
    {"assignment_name": "Clay Study", "due_date": "02/17", "weight": "15%", "course_name": "Material Histories"},
    {"assignment_name": "Map Quiz", "due_date": "02/21", "weight": "5%", "course_name": "World Rivers"},
    {"assignment_name": "Research Proposal", "due_date": "03/04", "weight": "20%", "course_name": "Literature Studio"},
    {"assignment_name": "Midterm Exam", "due_date": "03/06", "weight": "25%", "course_name": "Ecology Lab"},
    {"assignment_name": "Archive Project", "due_date": "03/07", "weight": "18%", "course_name": "Material Histories"},
    {"assignment_name": "Current Model", "due_date": "03/20", "weight": "12%", "course_name": "World Rivers"},
    {"assignment_name": "Lab Practical", "due_date": "04/03", "weight": "20%", "course_name": "Ecology Lab"},
    {"assignment_name": "Final Portfolio", "due_date": "04/17", "weight": "35%", "course_name": "Material Histories"},
    {"assignment_name": "Seminar Paper", "due_date": "04/24", "weight": "30%", "course_name": "Literature Studio"},
    {"assignment_name": "Final Exam", "due_date": "04/24", "weight": "40%", "course_name": "Ecology Lab"},
    {"assignment_name": "Watershed Design", "due_date": "04/28", "weight": "22%", "course_name": "World Rivers"},
]

DECOMPOSED_NAMES = {"Final Exam"}
CHIPPED_PEBBLES = [
    {"assignment_name": "Outline", "due_date": "03/16", "weight": "5%", "course_name": "Ecology Lab", "week": 10, "is_chip": True},
    {"assignment_name": "Draft 1", "due_date": "03/30", "weight": "5%", "course_name": "Ecology Lab", "week": 12, "is_chip": True},
    {"assignment_name": "Bibliography", "due_date": "04/06", "weight": "5%", "course_name": "Ecology Lab", "week": 13, "is_chip": True},
]


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i : i + 2], 16) for i in (0, 2, 4))


def center_x(y: float) -> float:
    return 550 + 118 * math.sin((y - 60) / 208) + 48 * math.sin(y / 71)


def slope_at(y: float) -> float:
    return (center_x(y + 2) - center_x(y - 2)) / 4


def point_at(y: float, offset: float = 0) -> tuple[float, float]:
    slope = slope_at(y)
    length = math.hypot(1, slope)
    normal_x = -1 / length
    normal_y = slope / length
    return center_x(y) + normal_x * offset, y + normal_y * offset


def path_points(offset: float = 0, step: int = 16) -> list[tuple[float, float]]:
    points = [point_at(y, offset) for y in range(TOP_Y, BOTTOM_Y + 1, step)]
    points.append(point_at(BOTTOM_Y, offset))
    return points


def week_from_due_date(mmdd: str) -> int:
    month, day = [int(part) for part in mmdd.split("/")]
    due = date(2026, month, day)
    days = (due - SEMESTER_START).days
    return min(16, max(1, days // 7 + 1))


def rock_class(weight: str) -> tuple[str, int]:
    percent = float(weight.rstrip("%"))
    if percent <= 5:
        return "The Pebble", 10
    if percent <= 15:
        return "The Stone", 30
    return "The Boulder", 70


def organic_rock_points(radius: float, wobble: float, count: int = 13) -> list[tuple[float, float]]:
    points = []
    for i in range(count):
        angle = math.tau * i / count
        r = radius * (1 + wobble * math.sin(i * 1.7) + wobble * 0.5 * math.cos(i * 2.6))
        points.append((math.cos(angle) * r, math.sin(angle) * r))
    return points


def rotate_points(
    points: list[tuple[float, float]], cx: float, cy: float, degrees: float
) -> list[tuple[float, float]]:
    radians = math.radians(degrees)
    cos_a, sin_a = math.cos(radians), math.sin(radians)
    return [(cx + x * cos_a - y * sin_a, cy + x * sin_a + y * cos_a) for x, y in points]


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size * SCALE)
        except OSError:
            pass
    return ImageFont.load_default()


def draw_centered_text(
    draw: ImageDraw.ImageDraw,
    xy: tuple[float, float],
    text: str,
    fill: str,
    text_font: ImageFont.ImageFont,
) -> None:
    x, y = xy
    bbox = draw.textbbox((0, 0), text, font=text_font)
    draw.text((x - (bbox[2] - bbox[0]) / 2, y - (bbox[3] - bbox[1]) / 2), text, fill=fill, font=text_font)


def draw_dashed_line(
    draw: ImageDraw.ImageDraw,
    points: list[tuple[float, float]],
    fill: tuple[int, int, int, int],
    width: int,
    dash: float = 22,
    gap: float = 28,
) -> None:
    draw_on = True
    remaining = dash
    last = points[0]
    for point in points[1:]:
        x1, y1 = last
        x2, y2 = point
        segment = math.hypot(x2 - x1, y2 - y1)
        consumed = 0.0
        while consumed < segment:
            step = min(remaining, segment - consumed)
            t1 = consumed / segment
            t2 = (consumed + step) / segment
            a = (x1 + (x2 - x1) * t1, y1 + (y2 - y1) * t1)
            b = (x1 + (x2 - x1) * t2, y1 + (y2 - y1) * t2)
            if draw_on:
                draw.line([a, b], fill=fill, width=width)
            consumed += step
            remaining -= step
            if remaining <= 0:
                draw_on = not draw_on
                remaining = dash if draw_on else gap
        last = point


def main() -> None:
    img = Image.new("RGB", (W * SCALE, H * SCALE), "#f4f0e7")
    draw = ImageDraw.Draw(img, "RGBA")

    title_font = font(68, bold=True)
    label_font = font(18, bold=True)
    small_font = font(13)
    rock_font = font(13, bold=True)
    legend_font = font(18, bold=True)

    draw.rectangle((0, 0, W * SCALE, H * SCALE), fill="#f4f0e7")

    def sxy(x: float, y: float) -> tuple[float, float]:
        return x * SCALE, y * SCALE

    def scaled_points(points: list[tuple[float, float]]) -> list[tuple[float, float]]:
        return [sxy(x, y) for x, y in points]

    draw.text(sxy(50, 28), "Semester River", fill="#25302e", font=title_font)
    draw.text(
        sxy(620, 44),
        "16 soft banks, 4 course currents, and assignment rocks placed by due week.",
        fill="#687571",
        font=small_font,
    )

    courses = list(dict.fromkeys(item["course_name"] for item in ASSIGNMENTS))[:4]
    course_palette = {course: PALETTES[index] for index, course in enumerate(courses)}

    for i in range(WEEKS):
        y = TOP_Y + i * WEEK_H
        draw.rectangle(sxy(28, y) + sxy(W - 28, y + WEEK_H), outline=(84, 92, 82, 34), width=SCALE)
        draw.text(sxy(58, y + 20), f"Week {i + 1}", fill="#56605c", font=label_font)

    centerline = scaled_points(path_points(0))
    draw.line(centerline, fill="#ded7c8", width=242 * SCALE, joint="curve")

    boulders_by_week: dict[int, int] = {}
    visible_assignments = [
        item for item in ASSIGNMENTS if item["assignment_name"] not in DECOMPOSED_NAMES
    ]
    visual_items = visible_assignments + CHIPPED_PEBBLES

    for item in visible_assignments:
        name, _ = rock_class(item["weight"])
        if name == "The Boulder":
            week = week_from_due_date(item["due_date"])
            boulders_by_week[week] = boulders_by_week.get(week, 0) + 1

    for week, count in boulders_by_week.items():
        if count < 2:
            continue
        y = TOP_Y + (week - 0.5) * WEEK_H
        cx, cy = sxy(*point_at(y, 0))
        rx = (142 + count * 18) * SCALE
        ry = (72 + count * 10) * SCALE
        draw.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=(120, 157, 162, 118))

    draw.line(centerline, fill="#9bb9bc", width=190 * SCALE, joint="curve")
    draw.line(scaled_points(path_points(-8)), fill=(110, 149, 155, 44), width=132 * SCALE, joint="curve")

    for index, course in enumerate(courses):
        rgb = hex_to_rgb(course_palette[course]["primary"])
        draw_dashed_line(
            draw,
            scaled_points(path_points(CURRENT_OFFSETS[index])),
            fill=(*rgb, 74),
            width=6 * SCALE,
        )

    for i in range(WEEKS):
        y = TOP_Y + i * WEEK_H
        p1 = sxy(center_x(y), y)
        p2 = sxy(center_x(y + 30), y + 30)
        draw.line([p1, p2], fill=(255, 255, 255, 104), width=2 * SCALE)

    for week, count in boulders_by_week.items():
        if count < 2:
            continue
        y = TOP_Y + (week - 0.5) * WEEK_H
        cx, cy = sxy(*point_at(y, 0))
        for i in range(5):
            ex = cx + (i - 2) * 30 * SCALE
            ey = cy + math.sin(i) * 18 * SCALE
            rx = (42 + i * 12) * SCALE
            ry = (15 + i * 5) * SCALE
            color = (244, 240, 231, 132) if i % 2 else (85, 127, 134, 118)
            draw.ellipse((ex - rx, ey - ry, ex + rx, ey + ry), outline=color, width=3 * SCALE)

    placed: dict[tuple[int, int], int] = {}
    for index, item in enumerate(visual_items):
        course_index = courses.index(item["course_name"])
        palette = course_palette[item["course_name"]]
        class_name, radius = ("The Pebble", 10) if item.get("is_chip") else rock_class(item["weight"])
        week = item.get("week") or week_from_due_date(item["due_date"])
        key = (week, course_index)
        stack = placed.get(key, 0)
        placed[key] = stack + 1

        y = TOP_Y + (week - 0.5) * WEEK_H + (stack - 0.5) * min(38, radius * 0.52)
        side_nudge = (-1 if stack % 2 == 0 else 1) * min(22, radius * 0.32)
        x, y = point_at(y, CURRENT_OFFSETS[course_index] + side_nudge)
        angle = (index * 23) % 31 - 15

        sx, sy = sxy(x, y)
        shadow_rx = radius * 0.78 * SCALE
        shadow_ry = radius * 0.32 * SCALE
        draw.ellipse((sx + 8 * SCALE - shadow_rx, sy + radius * 0.32 * SCALE - shadow_ry, sx + 8 * SCALE + shadow_rx, sy + radius * 0.32 * SCALE + shadow_ry), fill=(34, 38, 35, 56))

        rock_points = rotate_points(organic_rock_points(radius * SCALE, 0.12 if radius > 50 else 0.17), sx, sy, angle)
        draw.polygon(rock_points, fill=hex_to_rgb(palette["primary"]) + (255,), outline=(28, 31, 28, 72))
        highlight = rotate_points(
            [(x * 0.58 - radius * 0.18 * SCALE, y * 0.58 - radius * 0.18 * SCALE) for x, y in organic_rock_points(radius * SCALE, 0.16, 10)],
            sx,
            sy,
            angle,
        )
        draw.polygon(highlight, fill=hex_to_rgb(palette["highlight"]) + (108,))

        label = item["assignment_name"] if radius >= 30 or item.get("is_chip") else item["weight"]
        draw_centered_text(draw, (sx, sy + (radius + 20) * SCALE), label, "#25302e", rock_font)

    legend_y = 1860
    for index, course in enumerate(courses):
        palette = course_palette[course]
        x = 64 + index * 255
        draw.ellipse(sxy(x, legend_y) + sxy(x + 20, legend_y + 20), fill=hex_to_rgb(palette["primary"]) + (255,), outline=(37, 48, 46, 60))
        draw.text(sxy(x + 30, legend_y - 2), f"{course} · {palette['name']}", fill="#4f5a55", font=legend_font)

    img = img.resize((W, H), Image.Resampling.LANCZOS)
    img.save(OUT)
    print(OUT.resolve())


if __name__ == "__main__":
    main()
