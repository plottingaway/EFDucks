"""
Add Upstream Echo notification triggers to an existing assignments JSON file.

Usage:
    python add_upstream_echo.py assignments.json
    python add_upstream_echo.py assignments.json -o assignments_with_echo.json --year 2026
"""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

from extract_syllabus_assignments import add_upstream_echo_notifications


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Add 7-day and 3-day Upstream Echo reminders to Boulder assignments."
    )
    parser.add_argument("input", type=Path, help="Existing assignments JSON list.")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("assignments_with_echo.json"),
        help="Output JSON path. Defaults to assignments_with_echo.json.",
    )
    parser.add_argument(
        "--year",
        type=int,
        default=date.today().year,
        help="Calendar year used to calculate MM/DD trigger dates.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    assignments = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(assignments, list):
        raise ValueError("Input JSON must be a list of assignments.")

    data = add_upstream_echo_notifications(assignments, args.year)
    args.output.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"Added Upstream Echo notifications to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
