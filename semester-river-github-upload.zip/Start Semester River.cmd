@echo off
set "APP_DIR=%~dp0"
set "PYTHON_EXE=C:\Users\eleph\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "APP_URL=http://127.0.0.1:8765/"

if not exist "%PYTHON_EXE%" (
  echo Python runtime not found:
  echo %PYTHON_EXE%
  echo.
  echo Press any key to close.
  pause >nul
  exit /b 1
)

echo Starting Semester River...
echo.
echo Leave this window open while using the app.
echo In the in-app browser, open:
echo %APP_URL%
echo.
start "" "%APP_URL%"
echo Server output:
echo.
"%PYTHON_EXE%" -m http.server 8765 --bind 127.0.0.1 --directory "%APP_DIR%"
