"""
Extract assignment names, due dates, and grade weights from a syllabus PDF.

Usage:
    python extract_syllabus_assignments.py syllabus.pdf
    python extract_syllabus_assignments.py syllabus.pdf -o assignments.json

The script uses pdfplumber to read tables first, then falls back to scanning
plain text lines for date and percentage patterns.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
from typing import Iterable

try:
    import pdfplumber
except ImportError:  # pragma: no cover - user environment helper
    pdfplumber = None

try:
    from PyPDF2 import PdfReader
except ImportError:  # pragma: no cover - user environment helper
    PdfReader = None


MONTHS = {
    "jan": "01",
    "january": "01",
    "feb": "02",
    "february": "02",
    "mar": "03",
    "march": "03",
    "apr": "04",
    "april": "04",
    "may": "05",
    "jun": "06",
    "june": "06",
    "jul": "07",
    "july": "07",
    "aug": "08",
    "august": "08",
    "sep": "09",
    "sept": "09",
    "september": "09",
    "oct": "10",
    "october": "10",
    "nov": "11",
    "november": "11",
    "dec": "12",
    "december": "12",
}

DATE_PATTERNS = [
    re.compile(r"\b(?P<month>\d{1,2})[/-](?P<day>\d{1,2})(?:[/-]\d{2,4})?\b"),
    re.compile(
        r"\b(?P<month_name>Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
        r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sept?(?:ember)?|Oct(?:ober)?|"
        r"Nov(?:ember)?|Dec(?:ember)?)\.?\s+(?P<day>\d{1,2})(?:st|nd|rd|th)?"
        r"(?:,\s*\d{4})?\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?P<day>\d{1,2})(?:st|nd|rd|th)?\s+"
        r"(?P<month_name>Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
        r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sept?(?:ember)?|Oct(?:ober)?|"
        r"Nov(?:ember)?|Dec(?:ember)?)\.?(?:,\s*\d{4})?\b",
        re.IGNORECASE,
    ),
]
PERCENT_RE = re.compile(r"\b(?P<weight>\d{1,3}(?:\.\d+)?)\s*%")

ASSIGNMENT_HEADER_WORDS = ("assignment", "project", "exam", "quiz", "paper", "lab", "task")
DATE_HEADER_WORDS = ("due", "date", "deadline")
WEIGHT_HEADER_WORDS = ("weight", "percent", "percentage", "%", "grade", "points")

ROCK_PALETTES = [
    {
        "palette_name": "Slate Blue",
        "primary": "#5D6F8F",
        "shadow": "#34435E",
        "highlight": "#A8B4C8",
    },
    {
        "palette_name": "Moss Green",
        "primary": "#66785F",
        "shadow": "#354533",
        "highlight": "#A9B59B",
    },
    {
        "palette_name": "Terracotta",
        "primary": "#B96F53",
        "shadow": "#6F3F32",
        "highlight": "#D9A18D",
    },
    {
        "palette_name": "Deep Sand",
        "primary": "#A58A62",
        "shadow": "#5D4B34",
        "highlight": "#D6C39D",
    },
]


@dataclass(frozen=True)
class Assignment:
    assignment_name: str
    due_date: str
    weight: str

    def as_dict(self) -> dict[str, str]:
        return {
            "assignment_name": self.assignment_name,
            "due_date": self.due_date,
            "weight": self.weight,
        }


def clean_cell(value: object) -> str:
    """Normalize PDF table/text cell content."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def format_date(match: re.Match[str]) -> str | None:
    """Return MM/DD from a regex date match."""
    month = match.groupdict().get("month")
    day = match.groupdict().get("day")
    month_name = match.groupdict().get("month_name")

    if month_name:
        month = MONTHS.get(month_name.rstrip(".").lower())

    if not month or not day:
        return None

    month_int = int(month)
    day_int = int(day)
    if not (1 <= month_int <= 12 and 1 <= day_int <= 31):
        return None

    return f"{month_int:02d}/{day_int:02d}"


def find_date(text: str) -> tuple[str | None, tuple[int, int] | None]:
    for pattern in DATE_PATTERNS:
        match = pattern.search(text)
        if match:
            parsed = format_date(match)
            if parsed:
                return parsed, match.span()
    return None, None


def find_weight(text: str) -> tuple[str | None, tuple[int, int] | None]:
    match = PERCENT_RE.search(text)
    if not match:
        return None, None
    weight = match.group("weight")
    if weight.endswith(".0"):
        weight = weight[:-2]
    return f"{weight}%", match.span()


def weight_to_number(weight: str) -> float:
    match = PERCENT_RE.search(weight)
    if not match:
        raise ValueError(f"Could not read grade percentage from weight: {weight!r}")
    return float(match.group("weight"))


def rock_class_for_weight(weight: str) -> tuple[str, int]:
    percentage = weight_to_number(weight)
    if 1 <= percentage <= 5:
        return "The Pebble", 10
    if 5 < percentage <= 15:
        return "The Stone", 30
    if percentage > 15:
        return "The Boulder", 70
    return "Unweighted Fragment", 5


def palette_for_course(course_name: str) -> dict[str, str]:
    course_key = course_name.strip().lower() or "unknown course"
    digest = hashlib.sha256(course_key.encode("utf-8")).hexdigest()
    palette_index = int(digest[:8], 16) % len(ROCK_PALETTES)
    return ROCK_PALETTES[palette_index]


def add_visual_mass(
    assignments: Iterable[Assignment | dict[str, str]], course_name: str
) -> list[dict[str, object]]:
    """Add rock class, radius, and course-based color palette to assignments."""
    palette = palette_for_course(course_name)
    visual_assignments: list[dict[str, object]] = []

    for assignment in assignments:
        item = assignment.as_dict() if isinstance(assignment, Assignment) else dict(assignment)
        rock_class, radius = rock_class_for_weight(str(item.get("weight", "")))
        item.update(
            {
                "course_name": course_name,
                "rock_class": rock_class,
                "radius": radius,
                "color_palette": palette,
            }
        )
        visual_assignments.append(item)

    return visual_assignments


def parse_mmdd(value: str, year: int) -> date:
    month, day = value.split("/")
    return date(year, int(month), int(day))


def add_upstream_echo_notifications(
    assignments: Iterable[dict[str, object]], year: int | None = None
) -> list[dict[str, object]]:
    """Add 7-day and 3-day Upstream Echo triggers to every Boulder."""
    trigger_year = year or date.today().year
    scheduled: list[dict[str, object]] = []

    for assignment in assignments:
        item = dict(assignment)
        item["upstream_echo"] = []

        if item.get("rock_class") == "The Boulder":
            due_date = parse_mmdd(str(item["due_date"]), trigger_year)
            assignment_name = str(item["assignment_name"])
            item["upstream_echo"] = [
                {
                    "trigger": "7_days_before_due",
                    "trigger_date": (due_date - timedelta(days=7)).strftime("%m/%d"),
                    "message": (
                        f"The {assignment_name} is getting closer. "
                        "Is it time to chip it down?"
                    ),
                },
                {
                    "trigger": "3_days_before_due",
                    "trigger_date": (due_date - timedelta(days=3)).strftime("%m/%d"),
                    "message": (
                        f"The {assignment_name} is getting closer. "
                        "Is it time to chip it down?"
                    ),
                },
            ]

        scheduled.append(item)

    return scheduled


def header_score(cell: str, words: Iterable[str]) -> int:
    lower = cell.lower()
    return sum(1 for word in words if word in lower)


def choose_columns(header: list[str]) -> tuple[int | None, int | None, int | None]:
    """Identify likely name, date, and weight columns from a table header."""
    name_idx = date_idx = weight_idx = None

    for idx, cell in enumerate(header):
        if date_idx is None and header_score(cell, DATE_HEADER_WORDS):
            date_idx = idx
        if weight_idx is None and header_score(cell, WEIGHT_HEADER_WORDS):
            weight_idx = idx
        if name_idx is None and header_score(cell, ASSIGNMENT_HEADER_WORDS):
            name_idx = idx

    if name_idx is None:
        candidates = [idx for idx in range(len(header)) if idx not in {date_idx, weight_idx}]
        name_idx = candidates[0] if candidates else None

    return name_idx, date_idx, weight_idx


def extract_from_table(table: list[list[object]]) -> list[Assignment]:
    if not table or len(table) < 2:
        return []

    rows = [[clean_cell(cell) for cell in row] for row in table]
    header_index = next(
        (
            idx
            for idx, row in enumerate(rows[:4])
            if any(header_score(cell, DATE_HEADER_WORDS) for cell in row)
            and any(header_score(cell, WEIGHT_HEADER_WORDS) for cell in row)
        ),
        0,
    )

    header = rows[header_index]
    name_idx, date_idx, weight_idx = choose_columns(header)
    assignments: list[Assignment] = []

    for row in rows[header_index + 1 :]:
        if not any(row):
            continue

        joined = " ".join(row)
        due_date = clean_cell(row[date_idx]) if date_idx is not None and date_idx < len(row) else ""
        weight = clean_cell(row[weight_idx]) if weight_idx is not None and weight_idx < len(row) else ""
        name = clean_cell(row[name_idx]) if name_idx is not None and name_idx < len(row) else ""

        if not find_date(due_date)[0]:
            due_date = find_date(joined)[0] or ""
        else:
            due_date = find_date(due_date)[0] or ""

        if not find_weight(weight)[0]:
            weight = find_weight(joined)[0] or ""
        else:
            weight = find_weight(weight)[0] or ""

        if not name:
            name = remove_extracted_parts(joined)

        if name and due_date and weight:
            assignments.append(Assignment(name, due_date, weight))

    return assignments


def remove_extracted_parts(line: str) -> str:
    """Remove the first recognized date and percent from a text line."""
    spans: list[tuple[int, int]] = []
    _, date_span = find_date(line)
    _, weight_span = find_weight(line)
    if date_span:
        spans.append(date_span)
    if weight_span:
        spans.append(weight_span)

    result = line
    for start, end in sorted(spans, reverse=True):
        result = result[:start] + " " + result[end:]

    result = re.sub(r"\b(due|deadline|date|weight|grade|percent(?:age)?)\b", " ", result, flags=re.I)
    result = re.sub(r"[-|:;,]+", " ", result)
    return clean_cell(result)


def extract_from_text(text: str) -> list[Assignment]:
    assignments: list[Assignment] = []
    for raw_line in text.splitlines():
        line = clean_cell(raw_line)
        if len(line) < 6:
            continue

        due_date, _ = find_date(line)
        weight, _ = find_weight(line)
        if not due_date or not weight:
            continue

        name = remove_extracted_parts(line)
        if name:
            assignments.append(Assignment(name, due_date, weight))

    return assignments


def dedupe(assignments: Iterable[Assignment]) -> list[Assignment]:
    seen: set[tuple[str, str, str]] = set()
    unique: list[Assignment] = []
    for assignment in assignments:
        key = (
            assignment.assignment_name.lower(),
            assignment.due_date,
            assignment.weight,
        )
        if key not in seen:
            unique.append(assignment)
            seen.add(key)
    return unique


def extract_with_pdfplumber(pdf_path: Path) -> list[Assignment]:
    assignments: list[Assignment] = []
    all_text: list[str] = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            for table in page.extract_tables() or []:
                assignments.extend(extract_from_table(table))

            text = page.extract_text() or ""
            all_text.append(text)

    assignments.extend(extract_from_text("\n".join(all_text)))
    return assignments


def extract_with_pypdf2(pdf_path: Path) -> list[Assignment]:
    reader = PdfReader(str(pdf_path))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    return extract_from_text(text)


def extract_assignments(pdf_path: Path) -> list[Assignment]:
    if pdfplumber is not None:
        return dedupe(extract_with_pdfplumber(pdf_path))

    if PdfReader is not None:
        return dedupe(extract_with_pypdf2(pdf_path))

    raise RuntimeError(
        "No PDF library is installed. Install one with: pip install pdfplumber PyPDF2"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract assignment name, due date, and grade weight from a syllabus PDF."
    )
    parser.add_argument("pdf", type=Path, help="Path to the syllabus PDF.")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("assignments.json"),
        help="Path for the JSON output file. Defaults to assignments.json.",
    )
    parser.add_argument(
        "-c",
        "--course-name",
        default="",
        help="Course name used to choose a stable organic color palette.",
    )
    parser.add_argument(
        "--notification-year",
        type=int,
        default=date.today().year,
        help="Calendar year used to calculate MM/DD Upstream Echo trigger dates.",
    )
    parser.add_argument(
        "--print",
        action="store_true",
        help="Also print the JSON result to the console.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.pdf.exists():
        print(f"PDF not found: {args.pdf}", file=sys.stderr)
        return 1

    try:
        assignments = extract_assignments(args.pdf)
    except Exception as exc:
        print(f"Could not extract assignments: {exc}", file=sys.stderr)
        return 1

    course_name = args.course_name or args.pdf.stem
    data = add_visual_mass(assignments, course_name)
    data = add_upstream_echo_notifications(data, args.notification_year)
    args.output.write_text(json.dumps(data, indent=2), encoding="utf-8")

    if args.print:
        print(json.dumps(data, indent=2))

    print(f"Extracted {len(data)} assignment(s) to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
